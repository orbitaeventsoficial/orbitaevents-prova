'use client';
import React from 'react';
export default function Client() {
  return <div className="text-center py-32 text-6xl font-black text-green-500">FIESTAS LIVE</div>;
}
