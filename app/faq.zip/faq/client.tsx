'use client';
import Link from 'next/link';
import { useState } from "react";
import { Search, ChevronDown, MessageCircle } from "lucide-react";
import { FAQ_DATA } from './faq-data';

type CategoryType = "all" | "general" | "sonido" | "iluminacion" | "precios" | "reservas";

export default function FAQClient() {
  const [search, setSearch] = useState("");
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const [category, setCategory] = useState<CategoryType>("all");

  const WA_LINK = `https://wa.me/34699121023?text=${encodeURIComponent(
    "Hola, tengo una duda sobre [pregunta]"
  )}`;

  const filteredFAQs = FAQ_DATA.filter((faq) => {
    const matchesSearch =
      faq.q.toLowerCase().includes(search.toLowerCase()) ||
      faq.a.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = category === "all" || faq.category === category;
    return matchesSearch && matchesCategory;
  });

  return (
    <section className="mx-auto max-w-5xl px-4 py-20 text-white">
      <div className="text-center mb-12">
        <h1 className="text-5xl md:text-6xl font-black mb-4 bg-gradient-to-r from-white to-white/70 bg-clip-text text-transparent">
          Preguntas Frecuentes
        </h1>
        <p className="text-xl text-white/70">
          Todo lo que necesitas saber antes de reservar con nosotros.
        </p>
      </div>

      {/* Búsqueda + Filtros */}
      <div className="mb-12">
        <div className="relative max-w-md mx-auto mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-white/50" />
          <input
            type="text"
            placeholder="Buscar pregunta..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-3 bg-white/5 border border-white/20 rounded-xl focus:outline-none focus:border-[#d7b86e] transition"
          />
        </div>
        <div className="flex flex-wrap justify-center gap-2">
          {[
            { id: "all", label: "Todas" },
            { id: "general", label: "General" },
            { id: "sonido", label: "Sonido" },
            { id: "iluminacion", label: "Luces" },
            { id: "precios", label: "Precios" },
            { id: "reservas", label: "Reservas" },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setCategory(cat.id as CategoryType)}
              className={`px-4 py-2 rounded-xl text-sm transition-all ${
                category === cat.id
                  ? "bg-[#d7b86e] text-black"
                  : "bg-white/5 border border-white/20 hover:bg-white/10"
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Acordeón */}
      <div className="space-y-4">
        {filteredFAQs.map((faq, i) => (
          <div
            key={i}
            className="oe-card rounded-2xl border border-white/10 transition-all duration-300 hover:border-[#d7b86e]/30"
          >
            <button
              onClick={() => setOpenIndex(openIndex === i ? null : i)}
              className="w-full px-6 py-4 flex items-center justify-between text-left"
            >
              <h2 className="text-lg font-semibold pr-4">{faq.q}</h2>
              <ChevronDown
                className={`w-5 h-5 transition-transform ${
                  openIndex === i ? "rotate-180" : ""
                }`}
              />
            </button>
            {openIndex === i && (
              <div className="px-6 pb-4 text-white/80">
                <p className="mb-4">{faq.a}</p>
                <a
                  href={WA_LINK.replace("[pregunta]", faq.q)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-[#d7b86e] hover:text-white transition"
                >
                  <MessageCircle className="w-4 h-4" />
                  Preguntar por WhatsApp
                </a>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* CTA Final */}
      <div className="mt-12 text-center">
        <p className="text-xl text-white/80 mb-6">
          ¿No encuentras tu duda? ¡Hablemos!
        </p>
        <div className="flex justify-center gap-4">
          <a
            href={WA_LINK}
            target="_blank"
            rel="noopener noreferrer"
            className="oe-btn oe-btn-gold flex items-center gap-2"
          >
            <MessageCircle className="w-5 h-5" />
            WhatsApp
          </a>
          <Link href="/contacto" className="oe-btn flex items-center gap-2">
            Formulario
          </Link>
        </div>
      </div>
    </section>
  );
}