export const FAQ_DATA = [
  {
    q: "¿Qué incluye el servicio de discomóvil?",
    a: "Montaje completo: 2 EV ETX-15P 2000W, 4 B-150 LED 150W, Pioneer DJM-900 + CDJ-3000, micros Shure, técnico/DJ todo el evento, coordinación con venue. Todo con montaje en 30min.",
    category: "general",
  },
  {
    q: "¿Con cuánta antelación debo reservar?",
    a: "Para bodas: mínimo 3 meses. Temporada alta (mayo-septiembre): 6 meses. Para fiestas: 1 mes. ¡Reserva YA y asegura tu fecha!",
    category: "reservas",
  },
  {
    q: "¿Puedo personalizar la música?",
    a: "Sí. Envíanos tu playlist o indicaciones. Reunión previa para definir momentos clave (entrada, primer baile, barra libre). DJ lee la sala en vivo.",
    category: "general",
  },
  {
    q: "¿Qué pasa si hay limitador de sonido?",
    a: "Tenemos sistemas calibrados para limitadores. Ajustamos ganancia y ecualización para sonido potente sin cortes. Experiencia en venues con normativa estricta.",
    category: "sonido",
  },
  {
    q: "¿Hacéis eventos en Girona o Tarragona?",
    a: "Sí, toda Catalunya. Desplazamiento incluido en packs >600€. Resto +50€. Montaje en masías, fincas, hoteles.",
    category: "general",
  },
  {
    q: "¿Cómo es el pago y la reserva?",
    a: "50% señal para bloquear fecha. 50% una semana antes. Factura + contrato con horarios, equipos y condiciones. Pago por transferencia o Bizum.",
    category: "precios",
  },
  {
    q: "¿Qué pasa si llueve en evento al aire libre?",
    a: "Tenemos carpas impermeables y equipos IP54. Backup indoor si es necesario. Plan B siempre listo.",
    category: "general",
  },
  {
    q: "¿Incluye luces para pista de baile?",
    a: "Sí, 4 B-150 LED 150W con gobos, prisms y beam 6°. Luces ambiente + uplights opcionales.",
    category: "iluminacion",
  },
  {
    q: "¿Puedo alquilar solo el equipo sin DJ?",
    a: "Sí, desde 150€. Packs con EV ETX-15P, B-150 LED, Pioneer DJ. Con o sin técnico (+150€).",
    category: "precios",
  },
  {
    q: "¿Qué pasa si se cancela el evento?",
    a: "Devolución 100% si >30 días. 50% si <30 días. 0% si <7 días. Posibilidad de cambio de fecha.",
    category: "reservas",
  },
];
