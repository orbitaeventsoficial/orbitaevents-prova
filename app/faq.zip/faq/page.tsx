// app/faq/page.tsx
import type { Metadata } from "next";
import dynamic from "next/dynamic";
import Breadcrumbs from "@/app/components/seo/Breadcrumbs";
import { FAQ_DATA } from "./faq-data";

export const metadata: Metadata = {
  title: "Preguntas Frecuentes DJ Bodas Barcelona | Òrbita Events",
  description:
    "Respuestas reales a dudas sobre sonido, iluminación, precios y reservas. Todo lo que necesitas saber antes de contratar.",
  metadataBase: new URL(
    process.env.NEXT_PUBLIC_SITE_URL || "https://orbitaevents.com"
  ),
  alternates: { canonical: "/faq" },
  openGraph: {
    title: "Preguntas Frecuentes | Òrbita Events",
    description: "Todo sobre discomóvil, bodas, precios y limitadores de sonido.",
    url: "/faq",
    images: [
      {
        url: "/api/og?title=Preguntas%20Frecuentes",
        alt: "FAQ DJ bodas Barcelona",
      },
    ],
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Preguntas Frecuentes | Òrbita Events",
    description: "Respuestas sobre sonido, DJ y bodas en Barcelona.",
    images: ["/api/og?title=Preguntas%20Frecuentes"],
  },
  robots: { index: true, follow: true },
};

const FAQClient = dynamic(() => import("./client"));

export default function FAQPage() {
  return (
    <>
      <Breadcrumbs
        items={[
          { name: "Inicio", url: "/" },
          { name: "FAQ", url: "/faq" },
        ]}
      />

      {/* JSON-LD FAQPage */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "FAQPage",
            mainEntity: FAQ_DATA.map((faq) => ({
              "@type": "Question",
              name: faq.q,
              acceptedAnswer: {
                "@type": "Answer",
                text: faq.a,
              },
            })),
          }),
        }}
      />

      <FAQClient />
    </>
  );
}
