// app/servicios/alquiler/page.tsx
import type { Metadata } from 'next';
import Breadcrumbs from '@/app/components/seo/Breadcrumbs';
import ServiceJsonLD from '@/app/components/seo/ServiceJsonLD';
import FAQ from '@/app/components/seo/FAQ';
import Client from './Client';

export const metadata: Metadata = {
  title: 'Alquiler Sonido e Iluminación Barcelona | EV ETX + B-150 LED + Pioneer DJ | Órbita Events',
  description:
    'Alquiler equipamiento profesional: altavoces EV ETX-15P 2000W, 4 luces B-150 LED 150W, Pioneer DJM-900 + CDJ-3000. Con o sin técnico. Entrega/recogida incluida. Desde 150€/día. Barcelona, Lleida, Girona.',
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'https://orbitaevents.cat'),
  alternates: { canonical: '/servicios/alquiler' },
  openGraph: {
    title: 'Alquiler Equipo Audiovisual | EV ETX + B-150 LED + Pioneer DJ',
    description:
      'Sonido profesional EV, luces móviles LED, mesas DJ Pioneer. Con o sin técnico. Entrega incluida.',
    url: '/servicios/alquiler',
    images: [
      {
        url: '/api/og?title=Alquiler%20Equipo%20desde%20150€',
        alt: 'Alquiler equipamiento audiovisual profesional',
      },
    ],
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Alquiler Equipo | EV ETX + B-150 LED desde 150€',
    description: 'Entrega/recogida incluida. Con o sin técnico.',
    images: ['/api/og?title=Alquiler%20Equipo%20150€'],
  },
  robots: { index: true, follow: true },
  keywords: [
    'alquiler sonido Barcelona',
    'alquiler luces LED',
    'alquiler equipamiento DJ',
    'EV ETX alquiler',
    'B-150 LED alquiler',
    'Pioneer DJ alquiler',
    'alquiler equipo audiovisual',
    'alquiler sonido profesional',
    'alquiler iluminación eventos',
  ],
};

export default function AlquilerPage() {
  return (
    <>
      <Breadcrumbs
        items={[
          { name: 'Inicio', url: '/' },
          { name: 'Servicios', url: '/servicios' },
          { name: 'Alquiler', url: '/servicios/alquiler' },
        ]}
      />

      {/* JSON-LD OPTIMIZADO */}
      <ServiceJsonLD
        name="Alquiler Equipo Audiovisual Profesional"
        slugPath="/servicios/alquiler"
        description="Alquiler de equipamiento audiovisual profesional: altavoces EV ETX-15P 2000W, 4 luces B-150 LED 150W con beam 6° y gobos, Pioneer DJM-900 + CDJ-3000. Con o sin técnico. Entrega y recogida incluida en Barcelona y área metropolitana."
        serviceType={[
          'Alquiler sonido profesional',
          'Alquiler iluminación LED',
          'Alquiler equipamiento DJ',
          'Alquiler equipo audiovisual',
        ]}
        areaServed={['Barcelona', 'Girona', 'Tarragona', 'Lleida', 'Catalunya']}
        priceFrom="150"
        priceCurrency="EUR"
        availability="https://schema.org/InStock"
        aggregateRating={{
          ratingValue: 4.9,
          reviewCount: 89,
        }}
        offers={[
          {
            '@type': 'Offer',
            price: '280',
            priceCurrency: 'EUR',
            availability: 'https://schema.org/InStock',
            url: '/servicios/alquiler#pack-sonido',
            name: 'Pack Sonido Pro - 2x EV ETX + mesa',
            description: 'Fiestas pequeñas y eventos medianos',
          },
          {
            '@type': 'Offer',
            price: '220',
            priceCurrency: 'EUR',
            availability: 'https://schema.org/InStock',
            url: '/servicios/alquiler#pack-luces',
            name: 'Pack Luces LED - 4x B-150 LED',
            description: 'Iluminación ambiente y pista de baile',
          },
          {
            '@type': 'Offer',
            price: '380',
            priceCurrency: 'EUR',
            availability: 'https://schema.org/InStock',
            url: '/servicios/alquiler#pack-pioneer',
            name: 'Pack DJ Pioneer - DJM-900 + CDJ-3000',
            description: 'Equipamiento DJ profesional para eventos',
          },
          {
            '@type': 'Offer',
            price: '750',
            priceCurrency: 'EUR',
            availability: 'https://schema.org/InStock',
            url: '/servicios/alquiler#pack-completo',
            name: 'Pack Completo - Sonido + Luces + DJ + Técnico',
            description: 'Solución completa con técnico full día',
          },
        ]}
      />

      {/* CONTENIDO PRINCIPAL */}
      <Client />

      {/* FAQ AL FINAL */}
      <FAQ
        items={[
          {
            q: '¿Incluye entrega y recogida del equipamiento?',
            a: 'Sí, entrega y recogida incluida en Barcelona y área metropolitana (hasta 20km). Resto de Catalunya +50€. Montamos el equipo y hacemos prueba de sonido sin coste adicional.',
          },
          {
            q: '¿Puedo alquilar solo las luces B-150 LED sin sonido?',
            a: 'Sí, pack de 4 B-150 LED 150W desde 220€/día. Incluye control DMX, trípodes, cables y programación básica. Efectos gobos, prismas y beam 6° incluidos.',
          },
          {
            q: '¿Ofrecéis técnico con el alquiler?',
            a: 'Sí, técnico dedicado disponible por +150€/día. Incluye montaje completo, configuración, pruebas y soporte in situ durante todo el evento. Altamente recomendado para eventos importantes.',
          },
          {
            q: '¿Cuánto dura el período de alquiler?',
            a: '24 horas estándar (recogida día siguiente mismo horario). Fin de semana viernes-domingo +50% del precio diario. Semana completa consultar descuento especial.',
          },
          {
            q: '¿Qué pasa si hay algún problema técnico con el equipo?',
            a: 'Todo el equipamiento se revisa antes de cada alquiler. Si hay cualquier problema, tenemos equipo de backup disponible en menos de 2h (área Barcelona). Técnico disponible por teléfono 24h durante tu alquiler.',
          },
          {
            q: '¿Puedo alquilar equipamiento DJ Pioneer sin contratar DJ?',
            a: 'Sí, alquilamos Pioneer DJM-900 + 2x CDJ-3000 por 380€/día. Incluye cables XLR/RCA y soporte DJ. Ideal para DJs que quieren usar equipamiento profesional en su evento.',
          },
          {
            q: '¿Ofrecéis descuentos para alquileres de varios días o recurrentes?',
            a: 'Sí. Fin de semana (3 días) = +50% del precio diario. Semana completa = 4 días precio. Alquileres recurrentes o empresas consultar descuentos especiales por volumen.',
          },
          {
            q: '¿Qué documentación necesito para alquilar?',
            a: 'DNI/NIE y fianza reembolsable (varía según pack: 100-300€). Empresas: factura a nombre de empresa sin fianza. Fianza se devuelve al verificar estado equipamiento tras devolución.',
          },
        ]}
      />
    </>
  );
}